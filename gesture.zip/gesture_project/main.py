import cv2
import mediapipe as mp
import numpy as np
import pickle
import os
import time
import tkinter as tk
from tkinter import simpledialog, messagebox
from sklearn.neighbors import KNeighborsClassifier
from collections import deque
import pyttsx3
import threading
import queue

# ==========================================
# FIXED DATABASE PATH (WORKS AFTER RESTART)
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_FILE = os.path.join(BASE_DIR, "gesture_data.pkl")

# ==========================================
# TEXT TO SPEECH (QUEUE BASED - STABLE)
# ==========================================

engine = pyttsx3.init() 
engine.setProperty('rate', 150)
 # Start engine loop in background once
def tts_loop(): 
    engine.runAndWait() 
threading.Thread(target=tts_loop, daemon=True).start() 
def speak(text): 
    engine.say(text)

# ==========================================
# MEDIAPIPE SETUP (TWO HAND SUPPORT)
# ==========================================

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=2,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)
mp_draw = mp.solutions.drawing_utils

# ==========================================
# LOAD DATABASE
# ==========================================

if os.path.exists(DATABASE_FILE):
    with open(DATABASE_FILE, "rb") as f:
        gesture_db = pickle.load(f)
else:
    gesture_db = {"features": [], "labels": []}

# ==========================================
# FEATURE EXTRACTION (126 FEATURES)
# ==========================================

def extract_features_two_hands(hand_landmarks_list):

    all_features = []

    # Sort left to right
    hand_landmarks_list = sorted(
        hand_landmarks_list,
        key=lambda x: x.landmark[0].x
    )

    for hand_landmarks in hand_landmarks_list:

        wrist = hand_landmarks.landmark[0]
        middle_tip = hand_landmarks.landmark[12]

        scale = np.sqrt(
            (middle_tip.x - wrist.x) ** 2 +
            (middle_tip.y - wrist.y) ** 2
        )

        if scale == 0:
            scale = 1

        for lm in hand_landmarks.landmark:
            all_features.extend([
                (lm.x - wrist.x) / scale,
                (lm.y - wrist.y) / scale,
                (lm.z - wrist.z) / scale
            ])

    # Pad if only one hand
    if len(hand_landmarks_list) == 1:
        all_features.extend([0] * 63)

    return np.array(all_features)

# ==========================================
# SAFE TRAIN FUNCTION
# ==========================================

def train_knn():

    if len(gesture_db["features"]) == 0:
        return None

    X = []
    y = []

    for feature, label in zip(
        gesture_db["features"],
        gesture_db["labels"]
    ):
        if len(feature) == 126:
            X.append(feature)
            y.append(label)

    if len(X) == 0:
        return None

    X = np.array(X)
    y = np.array(y)

    knn = KNeighborsClassifier(n_neighbors=3)
    knn.fit(X, y)

    return knn

# ==========================================
# REGISTER GESTURE
# ==========================================

def register_gesture():

    cap = cv2.VideoCapture(0)
    samples = []
    count = 0

    messagebox.showinfo(
        "Instructions",
        "Show gesture clearly.\nCollecting 150 samples.\nPress Q to cancel."
    )

    while count < 150:

        ret, frame = cap.read()
        if not ret:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        if result.multi_hand_landmarks:

            for hand_landmarks in result.multi_hand_landmarks:
                mp_draw.draw_landmarks(
                    frame,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS
                )

            features = extract_features_two_hands(
                result.multi_hand_landmarks
            )

            samples.append(features)
            count += 1

        cv2.putText(frame,
                    f"Collecting: {count}/150",
                    (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 255, 0),
                    2)

        cv2.imshow("Register Gesture", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    if samples:
        label = simpledialog.askstring(
            "Input",
            "Enter meaning of this gesture:"
        )

        if label:

            for sample in samples:
                gesture_db["features"].append(sample)
                gesture_db["labels"].append(label)

            with open(DATABASE_FILE, "wb") as f:
                pickle.dump(gesture_db, f)

            messagebox.showinfo(
                "Success",
                f"Gesture '{label}' registered!"
            )

# ==========================================
# CONVERT GESTURE
# ==========================================

def convert_gesture():

    knn = train_knn()

    if knn is None:
        messagebox.showerror(
            "Error",
            "No gestures registered!"
        )
        return

    cap = cv2.VideoCapture(0)

    sentence = ""
    prediction_history = deque(maxlen=10)

    current_gesture = None
    hold_start_time = None
    gesture_spoken = False

    while True:

        ret, frame = cap.read()
        if not ret:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        prediction = None

        if result.multi_hand_landmarks:

            for hand_landmarks in result.multi_hand_landmarks:
                mp_draw.draw_landmarks(
                    frame,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS
                )

            features = extract_features_two_hands(
                result.multi_hand_landmarks
            )

            prediction = knn.predict([features])[0]

        prediction_history.append(prediction)

        if prediction is not None and \
           prediction_history.count(prediction) > 7:
            stable_gesture = prediction
        else:
            stable_gesture = None

        if stable_gesture is not None:

            if stable_gesture != current_gesture:
                current_gesture = stable_gesture
                hold_start_time = time.time()
                gesture_spoken = False

            else:
                if not gesture_spoken and hold_start_time:
                    if time.time() - hold_start_time >= 3:
                        sentence += current_gesture + " "
                        speak(current_gesture)
                        gesture_spoken = True

        else:
            current_gesture = None
            hold_start_time = None
            gesture_spoken = False

        cv2.putText(frame,
                    "Prediction: " +
                    (current_gesture if current_gesture else ""),
                    (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 255, 0),
                    2)

        cv2.putText(frame,
                    "Sentence: " + sentence,
                    (10, 80),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (255, 0, 0),
                    2)

        cv2.imshow("Convert Gesture", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# ==========================================
# GUI
# ==========================================

root = tk.Tk()
root.title("Professional Two-Hand Sign Language System")
root.geometry("450x300")

tk.Label(root,
         text="Dynamic Two-Hand Sign Recognition",
         font=("Arial", 14)).pack(pady=20)

tk.Button(root,
          text="Register Gesture",
          command=register_gesture,
          width=20,
          height=2).pack(pady=10)

tk.Button(root,
          text="Convert Gesture",
          command=convert_gesture,
          width=20,
          height=2).pack(pady=10)

root.mainloop()
